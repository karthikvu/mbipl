console.log("Script loaded");
height = $(window).height();
$(document).ready(function () {
    $('#mainImage').height(height + 'px');
    var pos1 = $('#img-2-text').offset().top;
    var elementIds = ['img-1-text', 'img-2-text', 'img-3-text'];
    details = {};
    $.each(elementIds, function (i, elemId) {
        details[elemId] = {
            top_of_element: $('#' + elemId).offset().top,
            bottom_of_element: $('#' + elemId).offset().top + $('#' + elemId).outerHeight()

        }
        $('#' + elemId).hide();
    });
    console.log(details);
    $(window).scroll(function () {
        var bottom_of_screen = $(window).scrollTop() + height;
        $.each(elementIds, function (i, elemId) {
            console.log(bottom_of_screen, details[elemId].top_of_element, bottom_of_screen, details[elemId].bottom_of_element);
            if (bottom_of_screen > details[elemId].top_of_element) {
                setTimeout(function () {
                    $('#' + elemId).fadeIn(500)
                }, 500);
                console.log('showing : ' + elemId);
            } else {
                // The element is not visible, do something else
            }

        });


    });


    $(window).scroll();

});